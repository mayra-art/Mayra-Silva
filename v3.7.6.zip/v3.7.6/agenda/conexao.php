<?php

$servername = "localhost";
$database = "brinquedotecail";
$username = "root";
$password = "";

$conexao = mysqli_connect($servername, $username, $password, $database );



?>