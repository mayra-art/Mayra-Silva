﻿<!DOCTYPE html>
<html lang="pt-br" >
<head>
  <meta charset="UTF-8">
  <title>Erro de permissão </title>
  <link rel="stylesheet" href="css/403.css">

</head>
<body>

<div class="container">
	<div class="forbidden-sign"></div>
    <h1>Erro de permissão</h1>
    <p>Você não tem permissão, consulte seu coordenador!</p>
</div>

  
</body>
</html>